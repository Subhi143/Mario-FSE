<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="tileset_gutter" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="924" columns="33">
 <image source="TestLibGdxProjectMurt/core/assets/tileset_gutter.png" width="594" height="504"/>
</tileset>
