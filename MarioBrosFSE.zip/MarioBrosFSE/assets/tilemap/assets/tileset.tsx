<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset_gutter.png" tilewidth="16" tileheight="16" tilecount="924" columns="33">
 <image source="Tileset_gutter.png" width="528" height="448"/>
</tileset>
