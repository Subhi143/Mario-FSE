package com.SubhiJustin.fse.Scenes;

import com.SubhiJustin.fse.SuperMarioFSE;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class Hud {
// where we create game logic etc.
	
public Stage stage;
private Viewport viewport; /* when game world moves we want the Hud to stay
the same so this is a new camera and viewport specifically for that */

private Integer worldTimer;
private float timeCount;
private Integer score;

Label countdownLabel;
Label scoreLabel;
Label timeLabel;
Label levelLabel;
Label worldLabel;
Label marioLabel;

public Hud(SpriteBatch sb) { // sb is SpriteBatch
	worldTimer = 300;
	timeCount = 0;
	score = 0;
	
	viewport = new FitViewport(SuperMarioFSE.V_HEIGHT, SuperMarioFSE.V_WIDTH, new OrthographicCamera());
	stage = new Stage(viewport, sb); 
	/* The stage is an empty box that provides organization
	by hosting a table inside of it and that table organizes the labels in a certain
	position inside of the stage */
	
	Table table = new Table(); // this will provide organization for the labels
	table.top(); 
	/* the table will be at the top of the stage to display lives,
	 timer, score and which level you're on */
	table.setFillParent(true); // table = size of stage
	
	countdownLabel = new Label(String.format("%03d", worldTimer), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// 3 digits long for the timer
	// bitmap font is a classic kind of 2d font perfect for this game, font color white
	scoreLabel = new Label(String.format("%06d", score), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// 6 digits long for the score
	timeLabel = new Label("TIME" , new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// this is just the word "time" so we can just write time, no need for String.format
	levelLabel = new Label("Level 1" , new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// change to level 2, 3, 4 etc. when making a new level
	worldLabel = new Label("WORLD" , new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// different world names for different levels
	marioLabel = new Label("MARIO" , new Label.LabelStyle(new BitmapFont(), Color.WHITE));
	// if user chooses Luigi at start screen, this should say Luigi instead of Mario
	
	table.add(marioLabel).expandX().padTop(20);
	table.add(worldLabel).expandX().padTop(20);
	table.add(timeLabel).expandX().padTop(20);
	
	table.row(); // creates a new row
	
	table.add(scoreLabel).expandX();
	table.add(levelLabel).expandX();
	table.add(countdownLabel).expandX();
	// tables are automatically spaced out into thirds, very helpful
	// table organizes character, world, timer, score, level at the top of the screen
	stage.addActor(table);
	
}


}
