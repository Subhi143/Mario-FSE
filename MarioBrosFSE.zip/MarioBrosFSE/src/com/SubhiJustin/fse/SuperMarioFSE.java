package com.SubhiJustin.fse;

import com.SubhiJustin.fse.Screens.PlayScreen;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;



@SuppressWarnings("unused")
public class SuperMarioFSE extends Game {
	public static final int V_WIDTH = 400;
	public static final int V_HEIGHT = 208;
	// our virtual width and height for the game
	
	public SpriteBatch batch; /* public Spritebatch so all java files in these packages
	can have access to it*/
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		setScreen(new PlayScreen(this));
		Sprite Mario;
		
	}

	@Override
	public void render () {
		super.render();
	}
	
}
