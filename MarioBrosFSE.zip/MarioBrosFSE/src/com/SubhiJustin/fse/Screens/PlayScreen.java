package com.SubhiJustin.fse.Screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.assets.loaders.resolvers.ExternalFileHandleResolver;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.SubhiJustin.fse.*;
import com.SubhiJustin.fse.Scenes.Hud;


public class PlayScreen implements Screen {
	
	private SuperMarioFSE game;
	
	
	private OrthographicCamera gamecam; /* orthographic camera used instead
	of side-scroller */
	private Viewport gamePort;
	private Hud hud;
	private TmxMapLoader maploader; // loads the map we created 
	private TiledMap map; // the map itslef
	private OrthogonalTiledMapRenderer renderer; // what renders our map to the screen
	

	public PlayScreen(SuperMarioFSE game) {
		this.game = game;
		hud = new Hud(game.batch);
		gamecam = new OrthographicCamera();
		gamePort = new FitViewport(SuperMarioFSE.V_WIDTH,SuperMarioFSE.V_HEIGHT, gamecam);
		/* FitViewPort will fit everything in regardless of how small or big 
		the screen size is, meaning this game should work for all screen sizes
		making it flexible and available for everyone */
		
		
		maploader = new TmxMapLoader();
		map = maploader.load("MarioMapFSE.tmx");
		//TiledMap map = new TmxMapLoader().load("MarioMapFSE.tmx");
		map.getLayers();
		System.out.println(map.getProperties());
		System.out.println(map.getClass());
		
		System.out.println(map.getLayers());
		System.out.println(map.getTileSets());
		//TiledMap map = new TmxMapLoader(new ExternalFileHandleResolver()).load("Level 1.tmx");
		renderer = new OrthogonalTiledMapRenderer(map);
		gamecam.position.set(SuperMarioFSE.V_WIDTH/2, SuperMarioFSE.V_HEIGHT/2, 0);
		/* now camera focuses on the middle of the screen instead of (0,0) because
		that's the default focus point, also the 0 at the end represents the z-axis (x,y,z) */
		
		
	}
	
	public void handleInput(float dt) {
		if(Gdx.input.isKeyPressed(Input.Keys.SPACE)) 
			gamecam.position.x+= 100*dt;
		
	}
	public void update (float dt) { // this method checks for updates
		handleInput(dt);// checks for any input
		
		gamecam.update(); // always updates the camera
		renderer.setView(gamecam);
		
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		

	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		
		
		renderer.render();
		game.batch.setProjectionMatrix(hud.stage.getCamera().combined);
		hud.stage.draw();
		renderer.setView(gamecam);
		game.batch.begin();
		Texture player;
		player = new Texture("mario.png");
		Sprite Mario = new Sprite(player);
		Mario.setSize(20,45);
		Mario.setPosition(0,25);
		Mario.draw(game.batch);
		game.batch.end();
		
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		gamePort.update(width, height);
		
		
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
